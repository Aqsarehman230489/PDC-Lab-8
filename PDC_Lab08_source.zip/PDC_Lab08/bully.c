/* bully.c - task 5 (optional): bully leader election with one crashed rank */
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#define TAG_ELECTION 1
#define TAG_OK 2
#define TAG_COORD 3
#define TAG_SHUTDOWN 4
#define TIMEOUT 0.5                        /* seconds to wait for an answer */

static void send_int(int dest, int tag, int value)
{
    MPI_Send(&value, 1, MPI_INT, dest, tag, MPI_COMM_WORLD);
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (size < 3) {
        if (rank == 0) fprintf(stderr, "run with at least 3 ranks\n");
        MPI_Finalize();
        return 1;
    }

    int crashed = size - 1;          /* the old leader is the highest rank */
    int initiator = 0;               /* the rank that notices the failure */
    if (argc > 1) crashed = atoi(argv[1]);
    if (argc > 2) initiator = atoi(argv[2]);
    if (initiator == crashed) initiator = (crashed + 1) % size;

    int leader = -1;
    if (rank == crashed) {
        printf("[rank %d] CRASHED: silent, ignores every message\n", rank);
        fflush(stdout);
        for (;;) {                   /* simulation plumbing: swallow messages */
            int v; MPI_Status st;
            MPI_Recv(&v, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG,
                     MPI_COMM_WORLD, &st);
            if (st.MPI_TAG == TAG_SHUTDOWN) break;
        }
    } else {
        int started = 0, got_ok = 0;
        double deadline = 0.0;
#define START_ELECTION() do { \
        started = 1; got_ok = 0; deadline = MPI_Wtime() + TIMEOUT; \
        for (int h = rank + 1; h < size; h++) \
            send_int(h, TAG_ELECTION, rank); } while (0)

        if (rank == initiator) {
            printf("[rank %d] detects that leader %d is down: starts election\n",
                   rank, crashed);
            fflush(stdout);
            START_ELECTION();
        }
        while (leader < 0) {
            int flag; MPI_Status st;
            MPI_Iprobe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &flag, &st);
            if (flag) {
                int v, from = st.MPI_SOURCE, tag = st.MPI_TAG;
                MPI_Recv(&v, 1, MPI_INT, from, tag, MPI_COMM_WORLD,
                         MPI_STATUS_IGNORE);
                if (tag == TAG_ELECTION) {
                    /* a lower rank asked: say i am alive, then run my own */
                    printf("[rank %d] got ELECTION from %d: replies OK\n",
                           rank, from);
                    fflush(stdout);
                    send_int(from, TAG_OK, rank);
                    if (!started) START_ELECTION();
                } else if (tag == TAG_OK) {
                    got_ok = 1;
                } else if (tag == TAG_COORD) {
                    leader = v;
                }
            }
            if (started && !got_ok && leader < 0 && MPI_Wtime() > deadline) {
                /* nobody above me answered in time, so i am the new leader */
                leader = rank;
                printf("[rank %d] no OK received: I am the new leader\n", rank);
                fflush(stdout);
                for (int l = 0; l < rank; l++)
                    if (l != crashed) send_int(l, TAG_COORD, rank);
                send_int(crashed, TAG_SHUTDOWN, rank);  /* let it exit */
            }
            /* no coordinator announced: try again */
            if (started && got_ok && leader < 0 &&
                MPI_Wtime() > deadline + 2 * TIMEOUT)
                START_ELECTION();
        }
        printf("[rank %d] accepts rank %d as leader\n", rank, leader);
        fflush(stdout);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    int *leaders = (rank == 0) ? malloc(size * sizeof(int)) : NULL;
    MPI_Gather(&leader, 1, MPI_INT, leaders, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if (rank == 0) {
        int expected = size - 1;
        if (expected == crashed) expected--;      /* highest surviving rank */
        int ok = 1;
        for (int r = 0; r < size; r++)
            if (r != crashed && leaders[r] != expected) ok = 0;
        printf("[bully] crashed=%d new_leader=%d expected=%d all_agree=%s\n",
               crashed, expected, expected, ok ? "YES" : "NO");
        free(leaders);
    }

    /* discard stray late messages, then leave */
    for (;;) {
        int flag; MPI_Status st; int v;
        MPI_Iprobe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &flag, &st);
        if (!flag) break;
        MPI_Recv(&v, 1, MPI_INT, st.MPI_SOURCE, st.MPI_TAG, MPI_COMM_WORLD,
                 MPI_STATUS_IGNORE);
    }
    MPI_Finalize();
    return 0;
}
