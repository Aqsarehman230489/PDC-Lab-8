/* hello_mpi.c - task 1: hello world with rank, size and processor name */
#include <stdio.h>
#include <string.h>
#include <mpi.h>

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);

    int rank, size, name_len, ver, subver;
    char name[MPI_MAX_PROCESSOR_NAME];

    /* who am i, how many of us, and which node am i running on */
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Get_processor_name(name, &name_len);

    /* order not defined */
    printf("Hello from rank %d of %d on %s\n", rank, size, name);
    fflush(stdout);
    MPI_Barrier(MPI_COMM_WORLD);

    /* ordered report through rank 0 */
    char line[MPI_MAX_PROCESSOR_NAME + 64];
    snprintf(line, sizeof line, "rank %d of %d on %s", rank, size, name);

    if (rank == 0) {
        MPI_Get_version(&ver, &subver);
        printf("--- ordered report collected by rank 0 (MPI standard %d.%d) ---\n",
               ver, subver);
        printf("%s\n", line);
        for (int src = 1; src < size; src++) {
            char buf[MPI_MAX_PROCESSOR_NAME + 64];
            MPI_Recv(buf, sizeof buf, MPI_CHAR, src, 0, MPI_COMM_WORLD,
                     MPI_STATUS_IGNORE);
            printf("%s\n", buf);
        }
    } else {
        /* send my line (with the terminating zero) to rank 0, tag 0 */
        MPI_Send(line, (int)strlen(line) + 1, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Finalize();
    return 0;
}
