/* lamport.c - task 4 (optional): lamport logical clocks over mpi messages */
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#ifndef ROUNDS
#define ROUNDS 4
#endif

enum { LOCAL = 0, SEND = 1, RECV = 2 };
static const char *type_name[] = { "local", "send ", "recv " };

typedef struct { int clock, rank, type, peer, msgts; } event_t;

static int compare_events(const void *a, const void *b)
{
    const event_t *x = a, *y = b;
    if (x->clock != y->clock) return x->clock < y->clock ? -1 : 1;
    return x->rank - y->rank;                     /* ties broken by rank */
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (size < 2) {
        if (rank == 0) fprintf(stderr, "run with at least 2 ranks\n");
        MPI_Finalize();
        return 1;
    }

    int per_rank = 3 * ROUNDS;             /* local + send + receive per round */
    event_t *mine = malloc(per_rank * sizeof(event_t));
    int n = 0, clock = 0;

    for (int r = 0; r < ROUNDS; r++) {
        clock++;                                  /* local event */
        mine[n++] = (event_t){ clock, rank, LOCAL, -1, 0 };

        int shift = 1 + r % (size - 1);    /* a different partner every round */
        int dest = (rank + shift) % size, src = (rank - shift + size) % size;
        int out, in;

        /* rule 1: tick before the send, the message carries the new value */
        clock++;
        out = clock;
        mine[n++] = (event_t){ clock, rank, SEND, dest, out };

        MPI_Sendrecv(&out, 1, MPI_INT, dest, r, &in, 1, MPI_INT, src, r,
                     MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        /* rule 2: on receive, clock = max(own clock, received stamp) + 1 */
        clock = (clock > in ? clock : in) + 1;
        mine[n++] = (event_t){ clock, rank, RECV, src, in };
    }

    event_t *all = NULL;
    if (rank == 0) all = malloc((size_t)size * per_rank * sizeof(event_t));
    MPI_Gather(mine, per_rank * 5, MPI_INT, all, per_rank * 5, MPI_INT, 0,
               MPI_COMM_WORLD);

    if (rank == 0) {
        int total = size * per_rank;
        event_t *merged = malloc(total * sizeof(event_t));
        for (int i = 0; i < total; i++) merged[i] = all[i];

        /* merge the logs: one list sorted by (clock, rank) */
        qsort(merged, total, sizeof(event_t), compare_events);

        printf("merged log (first %d of %d events):\n",
               total < 24 ? total : 24, total);
        printf("  clock rank event  peer msg_ts\n");
        for (int i = 0; i < total && i < 24; i++)
            printf("  %5d %4d %s %4d %6d\n", merged[i].clock, merged[i].rank,
                   type_name[merged[i].type], merged[i].peer, merged[i].msgts);

        int violations = 0, messages = 0;
        /* every receive must come after its matching send */
        for (int i = 0; i < total; i++) {
            if (all[i].type != RECV) continue;
            messages++;
            int found = 0;
            for (int j = 0; j < total; j++)
                if (all[j].type == SEND && all[j].rank == all[i].peer &&
                    all[j].peer == all[i].rank && all[j].clock == all[i].msgts) {
                    found = 1;
                    if (all[i].clock <= all[j].clock) violations++;
                }
            if (!found) violations++;
        }
        /* each rank's own clock must increase */
        for (int r = 0; r < size; r++)
            for (int k = 1; k < per_rank; k++)
                if (all[r * per_rank + k].clock <= all[r * per_rank + k - 1].clock)
                    violations++;

        printf("ranks=%d events=%d messages=%d causal_violations=%d "
               "consistent=%s\n", size, total, messages, violations,
               violations == 0 ? "YES" : "NO");
        free(merged); free(all);
    }
    free(mine);
    MPI_Finalize();
    return 0;
}
