/* master_worker.c - task 3: client-server task farm
 * rank 0 = server, all other ranks = clients */
#include <stdio.h>
#include <mpi.h>

#define TASKS 64
#define CHUNK 20000
#define TAG_REQUEST 1
#define TAG_TASK 2

static long count_primes(long lo, long hi)     /* count primes in [lo, hi) */
{
    long count = 0;
    for (long n = (lo < 2 ? 2 : lo); n < hi; n++) {
        int prime = 1;
        for (long d = 2; d * d <= n; d++)
            if (n % d == 0) { prime = 0; break; }
        count += prime;
    }
    return count;
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size < 2) {
        if (rank == 0) fprintf(stderr, "run with at least 2 ranks\n");
        MPI_Finalize();
        return 1;
    }

    if (rank == 0) {                               /* the server */
        long total = 0, next = 0;
        int stopped = 0, served[256] = { 0 };
        while (stopped < size - 1) {
            long msg[2];          /* {task finished (-1 = none), its result} */
            MPI_Status st;
            MPI_Recv(msg, 2, MPI_LONG, MPI_ANY_SOURCE, TAG_REQUEST,
                     MPI_COMM_WORLD, &st);
            if (msg[0] >= 0) { total += msg[1]; served[st.MPI_SOURCE]++; }
            /* -1 tells the client to stop */
            long task = (next < TASKS) ? next++ : -1;
            MPI_Send(&task, 1, MPI_LONG, st.MPI_SOURCE, TAG_TASK, MPI_COMM_WORLD);
            if (task < 0) stopped++;
        }
        long expected = count_primes(0, (long)TASKS * CHUNK);
        printf("[master-worker] tasks=%d workers=%d total_primes=%ld "
               "expected=%ld correct=%s\n", TASKS, size - 1, total, expected,
               total == expected ? "YES" : "NO");
        printf("tasks served per worker:");
        for (int w = 1; w < size; w++) printf(" rank%d=%d", w, served[w]);
        printf("\n");
    } else {                                       /* a client */
        long msg[2] = { -1, 0 };
        for (;;) {
            long task;
            /* send previous result (-1 the first time) and ask for work */
            MPI_Send(msg, 2, MPI_LONG, 0, TAG_REQUEST, MPI_COMM_WORLD);
            MPI_Recv(&task, 1, MPI_LONG, 0, TAG_TASK, MPI_COMM_WORLD,
                     MPI_STATUS_IGNORE);
            if (task < 0) break;                   /* no more tasks */
            msg[0] = task;
            msg[1] = count_primes(task * CHUNK, (task + 1) * CHUNK);
        }
    }

    MPI_Finalize();
    return 0;
}
