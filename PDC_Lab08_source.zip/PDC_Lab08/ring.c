/* ring.c - task 3: peer-to-peer style token ring (identical code on all ranks) */
#include <stdio.h>
#include <mpi.h>

#ifndef LAPS
#define LAPS 1000
#endif

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int right = (rank + 1) % size, left = (rank + size - 1) % size;
    long token = 0;

    MPI_Barrier(MPI_COMM_WORLD);
    double t0 = MPI_Wtime();
    for (int lap = 0; lap < LAPS; lap++) {
        if (rank == 0) {
            /* rank 0 starts the lap and gets the token back at the end */
            token += rank;
            MPI_Send(&token, 1, MPI_LONG, right, 0, MPI_COMM_WORLD);
            MPI_Recv(&token, 1, MPI_LONG, left, 0, MPI_COMM_WORLD,
                     MPI_STATUS_IGNORE);
        } else {
            /* others: take it from the left, add my rank, pass it right */
            MPI_Recv(&token, 1, MPI_LONG, left, 0, MPI_COMM_WORLD,
                     MPI_STATUS_IGNORE);
            token += rank;
            MPI_Send(&token, 1, MPI_LONG, right, 0, MPI_COMM_WORLD);
        }
    }
    double ms = (MPI_Wtime() - t0) * 1000.0;

    if (rank == 0) {
        long expected = (long)LAPS * size * (size - 1) / 2;
        printf("[ring] ranks=%d laps=%d token=%ld expected=%ld correct=%s "
               "time=%.2f ms\n", size, LAPS, token, expected,
               token == expected ? "YES" : "NO", ms);
        printf("messages sent=%d, average per message=%.4f ms\n",
               LAPS * size, ms / ((double)LAPS * size));
    }
    MPI_Finalize();
    return 0;
}
