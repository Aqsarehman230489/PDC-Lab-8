/* sum_mpi.c - task 2: same sum with message passing (collective and p2p) */
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#ifndef N
#define N 10000000
#endif
#ifndef REPS
#define REPS 3
#endif

static long long local_sum(const int *a, int n)
{
    long long s = 0;
    for (int i = 0; i < n; i++) s += a[i];
    return s;
}

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (N % size != 0) {
        if (rank == 0)
            fprintf(stderr, "N must be divisible by the number of ranks\n");
        MPI_Finalize();
        return 1;
    }
    int chunk = N / size;

    int *data = NULL;                      /* exists only on rank 0 */
    long long ref = 0;
    if (rank == 0) {
        data = malloc((size_t)N * sizeof(int));
        for (int i = 0; i < N; i++)
            data[i] = (int)(((long long)i * 7919) % 100003);
        ref = local_sum(data, N);          /* serial reference */
    }
    /* every rank has its own private buffer */
    int *mine = malloc((size_t)chunk * sizeof(int));

    double t_coll = 0, t_p2p = 0;
    long long total_coll = 0, total_p2p = 0;

    for (int r = 0; r < REPS; r++) {
        /* --- variant 1: collective communication --- */
        MPI_Barrier(MPI_COMM_WORLD);
        double t0 = MPI_Wtime();

        /* rank 0 splits the array into equal chunks, one per rank */
        MPI_Scatter(data, chunk, MPI_INT, mine, chunk, MPI_INT, 0,
                    MPI_COMM_WORLD);
        long long part = local_sum(mine, chunk);
        /* partial sums are added together on rank 0 */
        MPI_Reduce(&part, &total_coll, 1, MPI_LONG_LONG, MPI_SUM, 0,
                   MPI_COMM_WORLD);

        MPI_Barrier(MPI_COMM_WORLD);
        t_coll += MPI_Wtime() - t0;

        /* --- variant 2: explicit point-to-point messages --- */
        MPI_Barrier(MPI_COMM_WORLD);
        t0 = MPI_Wtime();
        if (rank == 0) {
            /* hand out chunk i to rank i */
            for (int i = 1; i < size; i++)
                MPI_Send(data + (size_t)i * chunk, chunk, MPI_INT, i, 1,
                         MPI_COMM_WORLD);

            /* rank 0 does chunk 0 itself */
            total_p2p = local_sum(data, chunk);

            /* collect one partial sum from every other rank */
            for (int i = 1; i < size; i++) {
                long long p;
                MPI_Recv(&p, 1, MPI_LONG_LONG, i, 2, MPI_COMM_WORLD,
                         MPI_STATUS_IGNORE);
                total_p2p += p;
            }
        } else {
            MPI_Recv(mine, chunk, MPI_INT, 0, 1, MPI_COMM_WORLD,
                     MPI_STATUS_IGNORE);
            long long p = local_sum(mine, chunk);
            MPI_Send(&p, 1, MPI_LONG_LONG, 0, 2, MPI_COMM_WORLD);
        }
        MPI_Barrier(MPI_COMM_WORLD);
        t_p2p += MPI_Wtime() - t0;
    }

    if (rank == 0) {
        printf("ranks=%d n=%d reps=%d reference_sum=%lld\n", size, N, REPS, ref);
        printf("[collective    ] sum=%lld correct=%s avg_time=%.2f ms\n",
               total_coll, total_coll == ref ? "YES" : "NO",
               t_coll / REPS * 1000.0);
        printf("[point-to-point] sum=%lld correct=%s avg_time=%.2f ms\n",
               total_p2p, total_p2p == ref ? "YES" : "NO",
               t_p2p / REPS * 1000.0);
        free(data);
    }
    free(mine);
    MPI_Finalize();
    return 0;
}
