/* sum_omp.c - task 2: the same sum with openmp shared memory, for comparison */
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#ifndef N
#define N 10000000
#endif
#ifndef REPS
#define REPS 3
#endif

int main(void)
{
    /* one array, seen by all threads */
    int *data = malloc((size_t)N * sizeof(int));
    for (int i = 0; i < N; i++)
        data[i] = (int)(((long long)i * 7919) % 100003);

    long long ref = 0;
    for (int i = 0; i < N; i++) ref += data[i];   /* serial reference */

    long long total = 0;
    double elapsed = 0;
    for (int r = 0; r < REPS; r++) {
        long long s = 0;
        double t0 = omp_get_wtime();

        /* split the loop among threads, private copies of s added at the end */
        #pragma omp parallel for reduction(+:s)
        for (int i = 0; i < N; i++)
            s += data[i];

        elapsed += omp_get_wtime() - t0;
        total = s;
    }

    printf("[openmp        ] threads=%d n=%d sum=%lld correct=%s "
           "avg_time=%.2f ms\n", omp_get_max_threads(), N, total,
           total == ref ? "YES" : "NO", elapsed / REPS * 1000.0);
    free(data);
    return 0;
}
